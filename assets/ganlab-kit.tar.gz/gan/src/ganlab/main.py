# coding: utf-8

"""
Implements GAN training inspired from :

    - Radford et al(2015) Unsupervised Representation Learning with Deep Convolutional Generative Adversarial Networks
    - Saliman et al (2016) Improved techniques for training GANs
      https://github.com/openai/improved-gan
"""

# Standard imports
import argparse
import logging
import sys
import os
from typing import Callable, Dict

# External imports
import yaml
import torch
import torch.optim as optim
from torch.utils.tensorboard import SummaryWriter
import torchvision
import deepcs.display
from deepcs.fileutils import generate_unique_logpath
import tqdm
import onnxruntime as ort

# Local imports
from . import data
from . import models


def label_smooth(labels, amplitude, num_target_classes):
    """
    Apply label smoothing to labels
    Consider labels is (B, )

    Args:
        labels: a (B, ) tensor with the the hard labels
        amplitude [0, 1]: the maximum amount of the probability mass to assign to the non class labels
        num_target_classes: the number of hard labels
    Returns:
        a tensor (B, num_target_classes) with the smoothed labels
    """
    # Fill everywhere  rand(0, 1) * amplitude / (num_target_classes - 1)
    smoothed_labels = (
        amplitude
        * torch.rand((labels.shape[0], num_target_classes), device=labels.device)
        / (num_target_classes - 1.0)
    )

    # For the correct class, we set its value to (1 - amplitude*rand(0, 1))
    # The probabilities do not sum to 1 but, almost
    smoothed_labels[:, labels] = 1 - amplitude * torch.rand(
        (labels.shape[0],), device=labels.device
    )  # (B, num_target_classes)

    # Normalize the soft labels so that they sum to 1, as a discrete distribution over the num_target_classes
    # labels
    norm_factor = smoothed_labels.sum(axis=1)  # (B, )
    smoothed_labels /= norm_factor[:, None]
    return smoothed_labels


def train(config):
    """
    Training of the algorithm
    """
    logger = logging.getLogger(__name__)
    logger.info("Training")

    # Parameters
    dataset = config["data"]["dataset"]
    debug = config["data"]["debug"]
    rootdir = config["data"]["rootdir"]
    nthreads = config["data"].get("nthreads", 6)
    batch_size = config["data"]["batch_size"]

    logdir = config["logging"]["logdir"]

    base_lr = config["optim"]["base_lr"]
    wdecay = config["optim"]["wdecay"]
    lblsmooth = config["optim"]["lblsmooth"]

    nepochs = config["nepochs"]

    dnoise = config["model"]["dnoise"]
    discriminator_base_c = config["model"]["discriminator_base_c"]
    generator_base_c = config["model"]["generator_base_c"]
    latent_size = config["model"]["latent_size"]
    dropout = config["model"]["dropout"]

    num_classes = (
        2  # TODO: we could be using the true labels for training the discriminator
    )
    sample_nrows = 8
    sample_ncols = 8

    use_cuda = torch.cuda.is_available()
    device = torch.device("cuda") if use_cuda else torch.device("cpu")
    
    # Configure CPU parallelism settings
    if not use_cuda:
        # Get the number of CPU threads on the system
        cpu_threads = os.cpu_count()
        logger.info(f"CPU mode: counted {cpu_threads} threads")
        logger.info(f"CPU mode: using {nthreads} workers for data loading")
        
        # Set the number of threads for inter-op parallelism (parallel ops)
        torch.set_num_threads(nthreads)

        # Set the number of threads for intra-op parallelism (within ops like matrix mult)
        torch.set_num_interop_threads(nthreads)


    # Dataloaders
    train_loader, valid_loader, img_shape = data.get_dataloaders(
        dataset_root=rootdir,
        cuda=use_cuda,
        batch_size=batch_size,
        n_threads=nthreads,
        dataset=dataset,
        small_experiment=debug,
    )

    # Model definition
    model = models.GAN(
        img_shape,
        dropout,
        discriminator_base_c,
        dnoise,
        num_classes,
        latent_size,
        generator_base_c,
    )
    model.to(device)
    
    if not use_cuda:
        # For CPU training with multiple cores
        model = torch.nn.DataParallel(model)
        logger.info(f"DataParallel enabled (processes threads internally)")

    # Optimizers
    # Handle both wrapped and unwrapped models
    if isinstance(model, torch.nn.DataParallel):
        critic = model.module.discriminator
        generator = model.module.generator
    else:
        critic = model.discriminator
        generator = model.generator
    
    ######################
    # START CODING HERE ##
    ######################
    # Step 1 - Define the optimizer for the critic
    optim_critic = None
    # Step 2 - Define the optimizer for the generator
    optim_generator = None

    # Step 3 - Define the loss (it must embed the sigmoid)
    loss = None

    ####################
    # END CODING HERE ##
    ####################

    # Callbacks
    summary_text = (
        "## Summary of the model architecture\n"
        + f"{deepcs.display.torch_summarize(model)}\n"
    )
    summary_text += "\n\n## Executed command :\n" + "{}".format(" ".join(sys.argv))
    summary_text += "\n\n## Args : \n {}".format(config)

    logger.info(summary_text)

    logdir = generate_unique_logpath(logdir, "gan")
    if not os.path.exists(logdir):
        os.makedirs(logdir)
    tensorboard_writer = SummaryWriter(log_dir=logdir, flush_secs=5)
    tensorboard_writer.add_text(
        "Experiment summary", deepcs.display.htmlize(summary_text)
    )

    with open(os.path.join(logdir, "summary.txt"), "w") as f:
        f.write(summary_text)

    save_path = os.path.join(logdir, "generator.pt")

    logger.info(f">>>>> Results saved in {logdir}")

    # Note: the validation data are only real images, hence the metrics below
    val_fmetrics = {
        "accuracy": lambda real_probas: (real_probas > 0.5).double().mean(),
        "loss": lambda real_probas: -real_probas.log().mean(),
    }

    # Define a fixed noise used for sampling
    fixed_noise = torch.randn(sample_nrows * sample_ncols, latent_size).to(device)

    # Generate few samples from the initial generator
    model.eval()
    fake_images = generator(X=fixed_noise)
    fake_images = (fake_images * data._IMG_STD + data._IMG_MEAN).clamp(0, 1.0)
    grid = torchvision.utils.make_grid(fake_images, nrow=sample_nrows, normalize=True)
    tensorboard_writer.add_image("Generated", grid, 0)

    imgpath = logdir + "/images/"
    if not os.path.exists(imgpath):
        os.makedirs(imgpath)
    torchvision.utils.save_image(grid, imgpath + "images-0000.png")

    # Training loop
    for e in range(nepochs):

        tot_dploss = tot_dnloss = tot_gloss = 0
        critic_paccuracy = critic_naccuracy = 0
        generator_accuracy = 0
        Ns = 0

        model.train()
        for ei, (X, _) in enumerate(tqdm.tqdm(train_loader)):

            # X is a batch of real data
            X = X.to(device)
            bi = X.shape[0]

            pos_labels = torch.ones((bi,)).long().to(device)
            neg_labels = torch.zeros((bi,)).long().to(device)

            ######################
            # START CODING HERE ##
            ######################

            # -- Discriminator training --

            # Step 1 - Forward pass for training the discriminator
            # Ganhacks #4: Use separate batchs for real and fake data
            real_logits, _ = None
            fake_logits, _ = None

            # Step 1 - Compute the real and fake labels for the discriminator
            discriminator_real_labels = None # (bi,)
            discriminator_fake_labels = None # (bi,)


            # Ganhacks #6: use soft labels
            # Apply a random label smoothing for this minibatch
            discriminator_smoothed_real_labels = label_smooth(
                discriminator_real_labels, lblsmooth, num_classes
            )  # (B, num_target_classes)
            discriminator_smoothed_fake_labels = label_smooth(
                discriminator_fake_labels, lblsmooth, num_classes
            )  # (B, num_target_classes)

            # Step 2 - Compute the loss of the critic
            D_ploss = None
            D_nloss = None
            Dloss = None + None

            # Step 3 - Reinitialize the gradient accumulator of the critic
            None

            # Step 4 - Perform the backward pass on the loss
            None

            # Step 5 - Update the parameters of the critic
            None

            ####################
            # END CODING HERE ##
            ####################

            # Computing of metrics for the discriminator
            # real_probs = torch.softmax(real_logits, dim=1)[:, 1]
            # fake_probs = torch.softmax(fake_logits, dim=1)[:, 0]
            critic_paccuracy += (real_logits[:, 1] > real_logits[:, 0]).sum().item()
            critic_naccuracy += (fake_logits[:, 0] > fake_logits[:, 1]).sum().item()
            tot_dploss += bi * D_ploss.item()
            tot_dnloss += bi * D_nloss.item()

            ######################
            # START CODING HERE ##
            ######################

            # -- Generator training --
            # The principle is to generator samples
            # and update the parameters of the generator only so that the frozen discriminator
            # considers the generated samples as real

            # Step 1 - Forward pass for training the generator
            fake_logits, _ = None

            # Step 1 - Compute the fake labels for the generator
            # The generator wants his generated images to be positive
            generator_fake_labels = None # (bi,)

            # Ganhacks #6: use soft labels
            # Apply a random label smoothing for this minibatch
            generator_fake_labels = label_smooth(
                generator_fake_labels, 0.0, num_classes
            )

            # Step 2 - Compute the loss of the generator
            Gloss = None

            # Step 3 - Reinitialize the gradient accumulator of the generator
            None

            # Step 4 - Perform the backward pass on the loss
            None

            # Step 5 - Update the parameters of the generator
            None
            ####################
            # END CODING HERE ##
            ####################

            # Update the metrics for the generator
            tot_gloss += bi * Gloss.item()
            generator_accuracy += (fake_logits[:, 1] > fake_logits[:, 0]).sum().item()

            # Accumulate the number of samples we saw
            Ns += bi

        # Normalize the metrics by the total number of samples
        critic_paccuracy /= Ns
        critic_naccuracy /= Ns
        tot_dploss /= Ns
        tot_dnloss /= Ns
        generator_accuracy /= Ns
        tot_gloss /= Ns

        # Evaluate the metrics on the validation set
        val_metrics = evaluate(model, device, valid_loader, val_fmetrics)

        logger.info(
            f"[Epoch {e+1}] \n"
            f"  - Critic BCELoss averaged on the real samples : {tot_dploss:.4f} , \n"
            f"  - Critic p-accuracy : Fraction of real samples considered as real by the discriminator : {critic_paccuracy:.2f}, \n"
            f"  - Critic BCELoss averaged on the fake samples : {tot_dnloss:.4f} , \n"
            f"  - Critic n-accuracy : Fraction of fake samples considered as fake by the discriminator :{critic_naccuracy:.2f},\n"
            f"  - Critic v-loss : CE Loss on real samples from the test fold :  {val_metrics['loss']:.4f}; \n"
            f"  - Critic accuracy on real samples from the validation fold : {val_metrics['accuracy']:.2f}, \n"
            f"  - Generator BCELoss averaged on the fake samples : {tot_gloss:.4f} \n"
            f"  - Generator accurarcy : fraction of generated samples considered as real by the discriminator {generator_accuracy:.2f}\n"
        )

        tensorboard_writer.add_scalar(
            "Critic p-loss : Critic BCELoss averaged on the real samples",
            tot_dploss,
            e + 1,
        )
        tensorboard_writer.add_scalar(
            "Critic p-accuracy : Fraction of real samples considered as real by the discriminator",
            critic_paccuracy,
            e + 1,
        )
        tensorboard_writer.add_scalar(
            "Critic n-loss : Critic BCELoss averaged on the fake samples",
            tot_dnloss,
            e + 1,
        )
        tensorboard_writer.add_scalar(
            "Critic n-accuracy : Fraction of fake samples considered as fake by the discriminator",
            critic_naccuracy,
            e + 1,
        )
        tensorboard_writer.add_scalar(
            "Critic v-loss : BCE Loss on real samples from the validation fold",
            val_metrics["loss"],
            e + 1,
        )
        tensorboard_writer.add_scalar(
            "Critic v-accuracy : Fraction of real samples from the validation fold considered as real by the discriminator",
            val_metrics["accuracy"],
            e + 1,
        )
        tensorboard_writer.add_scalar(
            "Generator BCELoss averaged on the fake samples", tot_gloss, e + 1
        )
        tensorboard_writer.add_scalar(
            "Generator accurarcy : fraction of generated samples considered as real by the discriminator",
            generator_accuracy,
            e + 1,
        )

        # Generate few samples from the generator
        model.eval()
        fake_images = generator(X=fixed_noise)
        # Unscale the images
        fake_images = (fake_images * data._IMG_STD + data._IMG_MEAN).clamp(0, 1.0)
        grid = torchvision.utils.make_grid(fake_images, nrow=sample_nrows)
        tensorboard_writer.add_image("Generated", grid, e + 1)
        torchvision.utils.save_image(grid, imgpath + f"images-{e+1:04d}.png")

        X, _ = next(iter(train_loader))
        real_images = X[: (sample_nrows * sample_ncols), ...]
        real_images = (real_images * data._IMG_STD + data._IMG_MEAN).clamp(0, 1.0)
        grid = torchvision.utils.make_grid(real_images, nrow=sample_nrows)
        tensorboard_writer.add_image("Real", grid, e + 1)
        # torchvision.utils.save_image(grid, imgpath + f"real-{e+1:04d}.png")

        # We save the generator
        logger.info(f"Generator saved at {save_path}")
        torch.save(generator, save_path)

        # Important: ensure the model is in eval mode before exporting !
        # the graph in train/test mode is not the same
        model.eval()
        dummy_input = torch.zeros((1, latent_size), device=device)
        torch.onnx.export(
            generator,
            dummy_input,
            logdir + "/generator.onnx",
            verbose=False,
            input_names=["input"],
            output_names=["output"],
            dynamic_axes={"input": {0: "batch"}, "output": {0: "batch"}},
        )  # At least opset 11 is required otherwise it seems nn.UpSample is not correctly handled
        logger.info(f"Generator onnx saved at {logdir}/generator.onnx")


def evaluate(
    model: torch.nn.Module,
    device: torch.device,
    loader: torch.utils.data.DataLoader,
    metrics: Dict[str, Callable],
):
    """
    Compute the averaged metrics given in the dictionnary.
    The dictionnary metrics gives a function to compute the metrics on a
    minibatch and averaged on it.
    """
    model.eval()

    tot_metrics = {m_name: 0.0 for m_name in metrics}
    Ns = 0
    for (inputs, targets) in loader:

        # Move the data to the GPU if required
        inputs, targets = inputs.to(device), targets.to(device)

        batch_size = inputs.shape[0]

        # Forward pass
        logits, _ = model(inputs, None)
        probas = logits.sigmoid()

        # Compute the metrics
        for m_name, m_f in metrics.items():
            tot_metrics[m_name] += batch_size * m_f(probas).item()
        Ns += batch_size

    # Size average the metrics
    for m_name, m_v in tot_metrics.items():
        tot_metrics[m_name] = m_v / Ns

    return tot_metrics


class ONNXWrapper:
    def __init__(self, use_cuda, modelpath):
        self.device = torch.device("cuda") if use_cuda else torch.device("cpu")
        providers = []
        if use_cuda:
            providers.append("CUDAExecutionProvider")
        providers.append("CPUExecutionProvider")
        self.inference_session = ort.InferenceSession(modelpath, providers=providers)
        input_shapes = self.inference_session.get_inputs()[
            0
        ].shape  # ['batch', latent_size]
        self.latent_size = input_shapes[1]

    def eval(self):
        # ONNX model cannot be switched from train to test
        pass

    def train(self):
        # ONNX model cannot be switch from test to train
        pass

    def __call__(self, torchX):
        output = self.inference_session.run(
            None, {self.inference_session.get_inputs()[0].name: torchX.cpu().numpy()}
        )[0]

        return torch.from_numpy(output).to(self.device)


def generate(modelpath):
    """
    Function to generate new samples from the generator
    using a pretrained network
    """

    # Parameters
    use_cuda = torch.cuda.is_available()
    device = torch.device("cuda") if use_cuda else torch.device("cpu")

    ######################
    # START CODING HERE ##
    ######################
    # Step 1 - Reload the generator using the ONNXWrapper class
    generator = None

    # Put the model in evaluation mode (due to BN and Dropout)
    generator.eval()

    # Generate some samples
    sample_nrows = 1
    sample_ncols = 8

    # Step 2 - Generate a noise vector, normaly distributed
    #          of shape (sample_nrows * sample_ncol, generator.latent_size)
    z = None

    # Step 3 - Forward pass through the generator
    #          The output is (B, 1, 28, 28)
    # The ONNXWrapper.__call__ implementation allows to forward propagate through ONNXWrapper
    # as you would do with normal nn.Module
    fake_images = None

    # Denormalize the result
    fake_images = fake_images * data._IMG_STD + data._IMG_MEAN
    ####################
    # END CODING HERE ##
    ####################

    grid = torchvision.utils.make_grid(fake_images, nrow=sample_ncols, normalize=True)
    torchvision.utils.save_image(grid, "generated1.png")
    logger.info("Image generated1.png generated")


if __name__ == "__main__":
    logging.basicConfig(stream=sys.stdout, format="%(message)s")
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    if len(sys.argv) < 2:
        logging.error(f"Incorrect number of arguments. Usage is : ")
        logging.error(f" - {sys.argv[0]} train config.yaml")
        logging.error(f" - {sys.argv[0]} generate generator.onnx")
        sys.exit(-1)

    if sys.argv[1] == "train":
        configpath = sys.argv[2]
        logging.info(f"Loading {configpath}")
        config = yaml.safe_load(open(configpath, "r"))
        train(config)

    elif sys.argv[1] == "generate": 
        onnxpath = sys.argv[2]
        generate(onnxpath)

    else:
        raise RuntimeError(f"Unknown command {sys.argv[1]}")
