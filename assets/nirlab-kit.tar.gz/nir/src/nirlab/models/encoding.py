# coding: utf-8

# Standard imports
import sys
import logging

# External imports
import torch
import torch.nn as nn
import matplotlib.pyplot as plt


# Local imports
import nirlab.utils as utils
from nirlab.models.hash_encoding import HashEmbedder

def build_encoder(dim_input, cfg):
    params = cfg["params"]
    return eval(f"{cfg['class']}(dim_input, params)")

class Positional(nn.Module):
    """
    This class implements the positional encoding as proposed in 
    the original NeRF paper Mildenhall et al.(2020)
    """

    def __init__(self, 
                 dim_input: int, 
                 cfg: dict): 
        super().__init__()
        
        self.dim_input = dim_input
        self.L = cfg["L"]

    def forward(self, X):
        """
        Given X as a collection of points on which to evaluate
        the embedding with X : (N, dim_input)

        We compute the positional encodings as a tensor of shape

        (N, dim_input * 2 * L)

        with cos/sin embeddings of L frequencies for each coordinate
        """
        # Compute the pulsations as 
        # 2**i pi  with i in [0, L-1]
        w = 2**(torch.arange(self.L, device=X.device)) * torch.pi # (L, )
        ww = torch.cat((w, w))

        # We then compute exp(i w c) for every coordinate
        # X is (N, d),  w is (2 * L, )

        ######################
        # START CODING HERE ##
        ######################
        # 4 lines of code

        # Step 1
        # we can broadcast X as (N, d,     1) 
        #              and w as (1, 1, 2 * L)
        # so that the product of both will compute the 2^l \pi x_i for every
        # component i and frequency l
        # to get the (N, d, 2L) frequencies

        # Step 2
        # Once these terms are computed, it remains to apply the cos/sin functions on their
        # respective part of the third dimension

        # Step 3
        # Finally, we flatten the (N, d, 2L) as a (N, d * 2L) tensor
    
        return torch.zeros(X.shape[0], self.dim_input * 2 * self.L)
        ####################
        # END CODING HERE ##
        ####################

def test_positional_encoding():
    cfg = { "L" : 4}
    dim_input = 1
    # Uniform sampling of the volume [-1, 1]^dim_input
    npoints = 1000
    cfg = {"class": "Positional", "params": {"L": 4}}

    enc = build_encoder(dim_input=dim_input, cfg=cfg)

    # X = -1. + 2.0 * torch.rand(npoints, dim_input)
    # The reshape can be usefull when dim_input = 1 to introduce that
    # dimension
    X = torch.linspace(0, 1., npoints).reshape(npoints, dim_input)

    print(X.shape)
    encodings = enc(X)
    print(encodings.shape)
   
    plt.figure()
    ncos = encodings.shape[1] // 2
    for n_enc in range(encodings.shape[1]):
        if n_enc < ncos:
            nl = n_enc
            color = "tab:red"
            label = f"cos(L={nl})"
            linewidth = 3./(1+2*nl)
        else:
            nl = n_enc - ncos
            color = "tab:blue"
            label = f"sin(L={nl})"
            linewidth = 3./(1+2*nl)
        plt.plot(X[:, 0], encodings[:, n_enc], 
                 color=color, 
                 linewidth=linewidth, 
                 label=label)
    # Show an x value and the encoding by blue dots on each curve
    x = 0.425
    enc_x = enc(torch.tensor([[x]]))
    for n_enc in range(encodings.shape[1]):
        plt.scatter(x, enc_x[0, n_enc], c='k', marker='x', zorder=10) 
    plt.vlines([x], ymin=-1, ymax=1, color='k')
    plt.legend()
    plt.savefig("positional_encoding.png")
    # plt.show()


if __name__ == "__main__":
    logging.basicConfig(stream=sys.stdout, level=logging.INFO, format="%(message)s")
    test_positional_encoding()

