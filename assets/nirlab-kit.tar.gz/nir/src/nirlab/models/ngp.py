# coding: utf-8

# Standard imports
import sys

# External imports
import torch
import torch.nn as nn


# Local imports
from . import encoding

class RealNGP(nn.Module):
    """
    Real valued Neural Graphic Primitive

    The first layer involves an Encoding then followed
    by dense layers to get the value of the function at the provided
    input coordinates.

    Arguments:
        dim_input (int): Number of input coordinates (e.g. 3 for x, y, t)
        dim_output (int): Number of output values (e.g. 1 for a scalar field)
        cfg (dict): Configuration for the encoding and MLP
    """

    def __init__(self, 
                 cfg: dict):
        super().__init__()

        self.dim_input = cfg["dim_input"]
        self.dim_output = cfg["dim_output"]

        # The input layer uses a hash encoding
        self.encoder = encoding.build_encoder(dim_input=self.dim_input, cfg=cfg["pos_encoding"])

        # Determine the dimensions of the embedding by doing a forward pass
        # through the encoder
        fake_input_size = (1, self.dim_input)
        fake_input = torch.zeros(*fake_input_size)
        output_encoding = self.encoder(fake_input) 
        output_encoding_size = output_encoding.shape[1] 

        # And then comes the FFNN with dense layers based
        # on the above coordinate encoding
        n_hidden_units = cfg["n_hidden_units"]
        n_hidden_layers = cfg["n_hidden_layers"]
        hidden_activation = nn.ReLU

        ######################
        # START CODING HERE ##
        ######################

        # Fill in the layers a FFNN made of n_hidden_layers linear
        # layers, followed by the activation function
        layers = []
        self.ffnn = nn.Sequential(*layers)
        ####################
        # END CODING HERE ##
        ####################

    def forward(self, x):
        """
        Do a forward pass through the NIR. 

        Arguments:
            x (torch.Tensor): (K, d_in) tensor of coordinates
                where to evaluate the representation, where d_in is the dimensionality
                of the input and K is the number to points to be evaluated
                or of shape (K, output_encoding_size) if skip_encoding is True.
        """
    
        # Computes the embedding of the points
        x = self.encoder(x) 
    
        # Hash Encoding can output in float16. Shall
        # we make the FFNN float16 as well ? 
        # Instead of converting the output of the encoding in float32 ?
        x = x.float()

        # Then go through the FFNN
        x = self.ffnn(x)

        return x

