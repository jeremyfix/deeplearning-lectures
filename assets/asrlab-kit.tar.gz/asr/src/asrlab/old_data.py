# coding: utf-8

# Standard imports
import os
import functools
import logging
import operator
from pathlib import Path
from typing import Union, Tuple
import pickle
import sys
import time


# External imports
import torch.nn as nn
from torch.nn.utils.rnn import (
    pad_sequence,
    pack_padded_sequence,
    pad_packed_sequence,
    PackedSequence,
)
import torch.utils.data
import torchaudio
from torchaudio.datasets import COMMONVOICE
from torchaudio.transforms import (
    Spectrogram,
    AmplitudeToDB,
    MelSpectrogram,
    FrequencyMasking,
    TimeMasking,
)
import matplotlib.pyplot as plt
import multiprocess

# Local imports
from asrlab import utils




if __name__ == "__main__":
    pass
    test_waveform_processor()
    test_dataloaders()
