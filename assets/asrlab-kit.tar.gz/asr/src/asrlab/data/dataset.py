# coding: utf-8

# Standard imports
import os
from pathlib import Path
from socket import SOL_ALG
from typing import Union
import pickle
import time
import logging

# External imports
import torch.nn as nn
import torch.utils.data
from torchaudio.datasets import COMMONVOICE
import multiprocess
import tqdm
import matplotlib.pyplot as plt

def load_dataset(
    fold: str,
    root: Union[str, Path],
    version: str,
    lang: str,
) -> torch.utils.data.Dataset:
    """
    Load the commonvoice dataset within the path
    commonvoice_root/commonvoice_version/lang

    In this folder, we expect to find the tsv files of CommonVoice

    Args:
        fold (str): the fold to load, e.g. train, dev, test, validated, ..
        root: the rootdir where to find the data
        version: the version of the dataset to consider
        lang: the language to load

    Returns:
        torch.utils.data.Dataset: ``dataset``
    """
    datasetpath = os.path.join(root, version, lang)
    if not os.path.exists(datasetpath):
        raise RuntimeError(f"The dataset path {datasetpath} does not exist.")

    return COMMONVOICE(root=datasetpath, tsv=fold + ".tsv")


def is_sample_in_timerange(i, ds, min_duration, max_duration):
    (w, r, _) = ds[i]
    return i, (not min_duration or min_duration <= (w.squeeze().shape[0] / r)) and (
        not max_duration or (w.squeeze().shape[0] / r) <= max_duration
    )

def get_duration(i, ds):
    (w, r, _) = ds[i]
    return len(w.squeeze()) / r

class DatasetFilter(object):
    """
    Dataset object filtering an original dataset based on the
    durations of its waveform
    """

    def __init__(
        self,
        ds: torch.utils.data.Dataset,
        min_duration: float,
        max_duration: float,
        cacheprefix: str,
        overwrite_index: bool,
    ) -> None:
        """
        Args:
            ds: the dataset to filter
            min_duration : the minimal duration in seconds
            max_duration : the maximal duration in seconds
            cacheprefix : the prefix of the cache file to which save the index files
            overwrite_index: whether or not to overwirte the cache file
        """

        # At construction we build a list of indices
        # of valid samples from the original dataset
        cachepath = cacheprefix + ".idx"
        if os.path.exists(cachepath) and not overwrite_index:
            logging.info(f"Loading the pre-generated index file {cachepath}")
            durations = pickle.load(open(cachepath, "rb"))
        else:
            logging.info(f"Generating the index files, processing {len(ds)} files, saved in {cachepath}"
            )
            # self.valid_indices = [
            #     i
            #     for i, (w, r, _) in tqdm.tqdm(enumerate(ds))
            #     if (not min_duration or min_duration <= (w.squeeze().shape[0] / r))
            #     and (not max_duration or (w.squeeze().shape[0] / r) <= max_duration)
            # ]

            indices = list(range(len(ds)))
            t0 = time.time()
            with multiprocess.Pool(processes=None) as pool:
                durations = list(
                    pool.map(
                        lambda idx, ds=ds:
                            get_duration(idx, ds),
                        indices,
                    ),
                )
            t1 = time.time()
            logging.info(f"Elapsed : {t1-t0} seconds")
            pickle.dump(durations, open(cachepath, "wb"))

        self.valid_indices = [i for i, di in enumerate(durations) if min_duration <= di <= max_duration]
        self.ds = ds

    def __getitem__(self, idx):
        return self.ds[self.valid_indices[idx]]

    def __len__(self):
        return len(self.valid_indices)


def dataset_exploration():
    fold = "train"
    root = "/mounts/datasets/datasets/CommonVoice"
    version = "v24.0"
    lang = "fr"

    ds = load_dataset(
        fold,
        root=root,
        version=version,
        lang=lang
    )
    
    # TODO: Explore the content of the dataset
    # Display the transcript of one of the samples
    # What is the duration, in seconds, of this sample ?
    


if __name__ == "__main__":
    logging.basicConfig(stream=sys.stdout, level=logging.INFO, format="%(message)s")
    dataset_exploration()
