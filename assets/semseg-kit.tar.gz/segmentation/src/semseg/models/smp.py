# coding: utf-8

# Standard imports

# External imports
import torch.nn as nn
import segmentation_models_pytorch as smp


def DeepLabV3Plus(cfg, input_size, num_classes):
    return None
